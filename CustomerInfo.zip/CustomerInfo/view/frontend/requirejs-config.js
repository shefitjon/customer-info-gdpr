var config = {
    map: {
        '*': {
            gdprRequest: 'Ruroc_CustomerInfo/js/gdpr-request'
        }
    }
};
